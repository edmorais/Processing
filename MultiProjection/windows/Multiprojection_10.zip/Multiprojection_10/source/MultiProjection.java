import processing.core.*; 
import processing.xml.*; 

import processing.video.*; 
import codeanticode.gsvideo.*; 
import fullscreen.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class MultiProjection extends PApplet {

/*
 * Multiple live / recorded video projection (Processing 1.5 only!)
 * by Eduardo Morais 2012
 *
 * Needs Fullscreen - http://www.superduper.org/processing/fullscreen_api/
 * and GSVideo (must be *test version 20110709*) - http://gsvideo.sourceforge.net/
 *
 * Tested on Windows. Requires Quicktime and WinVDIG *1.0.1* - http://www.eden.net.nz/7/20071008/
 */


/*
 * Boilerplate
 */

// libs:




// declarations

int $windowWidth, $windowHeight;
int $gridPositions;
int[] $allowCameras, $lockCameras;
boolean $videosDialog;
String $videosFolder;
boolean $Randomness, $Playing;
int $liveWidth, $liveHeight;
boolean $fillScreen;
int $fadeSpeed;
boolean $ratioAdjust;
String $okVideos;
String[] $Cameras;
Capture[] $Live;
int $liveLength;
int[] $lockLive = {};
int $Ghosting, $FX;
float $FXLevel;
int $numPixels;
int[] $previousFrame;
String[] $Videos;
int $videosIndex, $videosTotal;
GSMovie $Video;
int[] $Grid;
FullScreen $Canvas;
int $canvasWidth, $canvasHeight;
int $offsetY, $widths;
int $fade, $fading;
boolean $showHelp;
String $Help;
PFont $theFont;


/*
 * Config:
 */

Config $config;


public void setup() {

	try {
		$config = new Config();
		// load a configuration from a file inside the data folder
		$config.load(openStream("config.txt"));

		// all values returned by the getProperty() method are Strings
		// so we need to cast them into the appropriate type ourselves
		// this is done for us by the convenience Config class

		$windowWidth 			= $config.getInt("mp.width", 640);
		$windowHeight 			= $config.getInt("mp.height", 480);

		$gridPositions			= $config.getInt("mp.gridPositions", 3);

		$allowCameras			= $config.getIntArray("live.allow");
		$lockLive				= $config.getIntArray("live.lock");

		$videosDialog			= $config.getBoolean("video.dialog", false);
		$videosFolder			= $config.getString("video.folder", "videos");
		$Randomness 			= $config.getBoolean("video.randomness", false);
		$Playing				= $config.getBoolean("video.playing", true);
		$liveWidth				= $config.getInt("live.width", 640);
		$liveHeight				= $config.getInt("live.height", 480);
		$fillScreen				= $config.getBoolean("mp.fillScreen", false);
		$fadeSpeed				= $config.getInt("mp.fadeSpeed", 4);
		$ratioAdjust			= $config.getBoolean("live.ratioAdjust", false);

		// allowed video formats, separated by pipes(|):
		$okVideos 				= $config.getString("video.formats", "mov|mpg");


		// declarations - camera:
		$liveLength = 0;
		$Ghosting = 1;			// webcam ghosting
		$FX = 0;		 		// FX
		$FXLevel = 127;			// FX - level

		// declarations - video files:
		$videosIndex = 0; 		// current video
		$videosTotal = 0; 		// number of videos

		// declarations - screen & measures
		$canvasWidth = $windowWidth;
		$canvasHeight = $windowHeight;
		$offsetY = 0; 			// vertical offset
		$fade = 0;				// fade tint level
		$fading = $fadeSpeed;	// fade effect speed


		// help:
		$showHelp = false;
		$Help = "MultiProjection 1.0 "+
			"by Eduardo Morais 2012 - www.eduardomorais.pt\n\n"+

			"SPACE: Video play / pause\n"+
			"N / F9: Next video / random video\n\n"+

			"ENTER: Toggle fill - horizontal grid mode\n"+
			"G: Toggle number of grid positions\n"+
			"PAGEUP, PAGEDOWN: Adjust vertical position\n"+
			"1..5: Toggle grid position content\n"+
			"6..0: Toggle effects on-off\n"+
			"UP, DOWN: Adjust effect level\n"+
			"LEFT, RIGHT: Adjust ghosting level\n\n"+

			"S / C: Swap video with camera / between cameras\n"+
			"F3: Enter / leave fullscreen mode\n"+
			"F: Fade from / to black\n\n"+
			"Q: Quit program\n"+
			"F1: Toggle help...";

		// GO!
		go();

	}
		catch(IOException e) {
		println("couldn't read config file...");
	}
}


/*
 * INCLUDED FILES:
 *
 * App:				app.pde
 * Keybindings:		inc_keys.pde
 * Visual effects:	inc_fx.pde
 * Misc. functions:	inc_utilities.pde
 *
 */
/*
 * Multiple live / recorded video projection (Processing 1.5 only!)
 * by Eduardo Morais 2012
 */


/*
 * Main proggy
 */

//
// START:
//
public void go() {
	// set screen:
	size($windowWidth, $windowHeight);
	frame.setTitle("MultiProjection >>> press F1 for help");
	background(0);
	smooth();
	noCursor();
	$Canvas = new FullScreen(this);
	$Canvas.setShortcutsEnabled(false);
	$Canvas.setResolution(screen.width, screen.height);
	boolean EXITING = false;
	$Grid = new int[$gridPositions+3];
	for (int i = 0; i < $Grid.length; i++) {
		$Grid[i] = 999;
	}

	// be safe:
	if ($gridPositions < 2 || $gridPositions > 5) {
		$gridPositions = 2;
	}

	// needed for help:
	$theFont = createFont("sans-serif bold", 14, true);
	textFont($theFont);

	// select videos folder:
	while ($videosTotal < 1 && !EXITING) {
		// choosing video folder?
		if ($videosDialog) {
			$videosFolder = selectFolder("Select videos folder");
		} else {
			$videosFolder = sketchPath + "/" + $videosFolder;
		}
		if ($videosFolder != null) {
			String[] filenames = listFileNames($videosFolder);
			if (filenames != null) {
				$videosTotal = filenames.length;
			}
			$videosDialog = true;	// if the folder has no videos, ask for a new one
		} else {
			EXITING = true;
			exit();
		}
	}

	if ($videosTotal > 0 || !EXITING) {
		// load video files:
		String[] filenames = listFileNames($videosFolder);
		println("Video files detected:\n---");
		$Videos = new String[filenames.length];
		for (int i = 0; i < filenames.length; i++) {
			$Videos[i] = $videosFolder + "/" + filenames[i];
		}
		println($Videos);
		println("\n");
		$Grid[0] = 100;

		// check for cameras:
		String[] cams = Capture.list();
		if (cams.length > 0) {
			println("Detected video devices:\n---");
			println(cams);
			// load cameras:
			int c = 0;
			String[] $Cameras = new String[$allowCameras.length];
			for (int i = 0; i < $allowCameras.length; i++) {
				if ($allowCameras[i] < cams.length) {
					$Cameras[c] = cams[$allowCameras[i]];
					println("Initializing ("+$allowCameras[i]+"): "+$Cameras[c]);

					// add to locked camera position?
					if (int_in_array($allowCameras[i], $lockCameras)) {
						$lockLive = append($lockLive, c);
					}

					c++;
				} else {
					$Cameras = shorten($Cameras);
				}
			}
			if ($Cameras.length > 0) {
				// initialize cameras:
				$Live = new Capture[$Cameras.length];
				for (int i = 0; i < $Cameras.length; i++) {
					println($Cameras[i]);
					$Live[i] = new Capture(this, $liveWidth, $liveHeight, $Cameras[i]);
					if (i < $Grid.length - 1) {
						$Grid[i+1] = i;
					}
				}
				$liveLength = $Live.length;
				// Create an array to store the previously captured frame
				$numPixels = $liveWidth * $liveHeight;
				$previousFrame = new int[$numPixels];
				// Adjust AR
				liveRatioAdjust();
			} else {
				println("ERROR! NO COMPATIBLE CAMERAS FOUND.");
				exit();
			}
		} else {
			println("ERROR! NO CAMERAS FOUND.");
			exit();
		}
	}
}


//
// MAIN LOOP:
//
public void draw() {

	if ($showHelp) {
	// help:
		background(0);
		fill(255);
		text($Help,40,50);

	} else {

		// calculations:
		$widths = $canvasWidth/$gridPositions;
		int posY = ($canvasHeight/2) - ($canvasHeight/($gridPositions*2)) + $offsetY;

		// fade
		if ($fading != 0) {
			if ($fade > 255) {
				$fade = 255;
				$fading = 0;
			}
			if ($fade < 0) {
				$fade = 0;
				$fading = 0;
			}
			background(0);
			tint(255, $fade);
			$fade += $fading;
		}

		// already drew fullscreen?
		boolean madeFull = false;

		// prepare webcam:
		for (int c = 0; c < $liveLength; c++) {
			if ($Live[c] != null && $Live[c].available()) {
				$Live[c].read();

				// effects:
				if ($FX == 1) {
					FX_gamma($Live[c]);
				}
				if ($FX == 2) {
					FX_add($Live[c]);
				}
				if ($FX == 3) {
					FX_difference($Live[c]);
				}
				if ($FX == 4) {
					float level = map($FXLevel, 0, 255, 2, 16);
					$Live[c].filter(POSTERIZE, level);
				}
				if ($FX == 5) {
					$Live[c].filter(GRAY);
				}
			}
		}

		// prepare movie:
		videoPlaylist(false, $Randomness); // call this
		if ($Video != null && $Video.available()) {
			$Video.read();
		}

		//
		// put things on screen!
		//
		for (int G = 0; G < $gridPositions; G++) {
			// horizontal position:
			int posX = G * $widths;

			//
			// DRAW MOVIE:
			//
			if ($Grid[G] == 100 && !madeFull && $Video != null) {
				if ($fade > 0) {
					if ($fading == 0){
						noTint();
					}
					if ($fillScreen) {
						// single video:
						image($Video, 0, 0, $canvasWidth, $canvasHeight);
						madeFull = true;
						break;
					} else {
						// dual video:
						image($Video, posX, posY, $widths-1, $canvasHeight/$gridPositions);
					}
				}
				continue;
			}

			//
			// DRAW WEBCAM:
			//
			if ($Grid[G] < $liveLength && !madeFull) {

				if ($Live[$Grid[G]] != null && $fade > 0) {
					if ($Ghosting > 1 && $fading == 0) {
						tint(255, 255/$Ghosting);
					} else if ($fading == 0){
						noTint();
					}

					// draw video:
					if ($fillScreen) {
						// single video:
						image($Live[$Grid[G]], 0, 0, $canvasWidth, $canvasHeight);
						madeFull = true;
						break;
					} else {
						// multi video:
						image($Live[$Grid[G]], posX, posY, $widths-1, $canvasHeight/$gridPositions);
					}
				}
			}
		}
	}
}


//
// VIDEO PLAYLIST CONTROL:
// (bool advance: force jump to next video)
//
public void videoPlaylist(boolean advance, boolean atRandom) {
	if(($Video==null || !$Video.isPlaying() || advance) && $Playing) {
		// advance to new:
		if ($Video!=null) {
			$Video.dispose();
			// random?
			if (atRandom && $videosTotal > 1 ) {
				int rn = $videosIndex;
				while (rn == $videosIndex) {
					rn = floor(random($videosTotal));
				}
				$videosIndex = rn;
			} else {
				$videosIndex++;
			}
		}
		if ($videosIndex == $videosTotal) {
			$videosIndex = 0;
		}
		// init new video:
		$Video = new GSMovie(this, $Videos[$videosIndex]);
		println("\nPlaying "+ $Video.getFilename());
		$Video.goToBeginning();
		$Video.noLoop();
		$Video.play();
	}
}



//
// CAMERA RATIO ADJUST:
//
public void liveRatioAdjust() {
	if ($ratioAdjust) {
		float ratio = PApplet.parseFloat($canvasWidth)/PApplet.parseFloat($canvasHeight);
		// vertical crop (eg. 4x3 capture in 16x9 screen):
		int liveCropW = $liveWidth;
		int liveCropH = floor($liveWidth / ratio);
		int liveCropY = floor(($liveHeight-liveCropH)/2);
		int liveCropX = 0;
		// horizontal crop (eg. 16x9 capture in 4x3 screen):
		if (liveCropY < 0) {
			liveCropW = floor($liveHeight * ratio);
			liveCropH = $liveHeight;
			liveCropY = 0;
			liveCropX = floor(($liveWidth-liveCropW)/2);
		}
		println("Capture ratio adjust on: R "+ratio+" / H "+liveCropH+" / Y "+liveCropY);
		for (int i = 0; i < $liveLength; i++) {
			if ($Live[i] != null) {
				$Live[i].crop(liveCropX, liveCropY, liveCropW, liveCropH);
			}
		}
	} else {
		println("Capture ratio adjust off");
		for (int i = 0; i < $liveLength; i++) {
			if ($Live[i] != null) {
				$Live[i].crop(0, 0, $liveWidth, $liveHeight);
				$Live[i].noCrop();
			}
		}
	}

}
/*
 * Multiple live / recorded video projection (Processing 1.5 only!)
 * by Eduardo Morais 2012
 */

/*
 * Visual effects
 */

//
// FX: difference - based on Frame Differencing by Golan Levin
//
public void FX_difference(PImage video) {
	video.loadPixels(); // Make its pixels[] array available
        $numPixels = video.pixels.length;

	int movementSum = 0; // Amount of movement in the frame
	for (int i = 0; i < $numPixels; i++) { // For each pixel in the video frame...
		int currColor = video.pixels[i];
		int prevColor = $previousFrame[i];
		// Extract the red, green, and blue components from current pixel
		int currR = (currColor >> 16) & 0xFF; // Like red(), but faster
		int currG = (currColor >> 8) & 0xFF;
		int currB = currColor & 0xFF;
		// Extract red, green, and blue components from previous pixel
		int prevR = (prevColor >> 16) & 0xFF;
		int prevG = (prevColor >> 8) & 0xFF;
		int prevB = prevColor & 0xFF;
		// Compute the difference of the red, green, and blue values
		int diffR = abs(currR - prevR);
		int diffG = abs(currG - prevG);
		int diffB = abs(currB - prevB);
		// Add these differences to the running tally
		movementSum += diffR + diffG + diffB;
		// Render the difference image to the screen
		// video.pixels[i] = color(diffR, diffG, diffB);
		// The following line is much faster, but more confusing to read
		video.pixels[i] = 0xff000000 | (diffR << 16) | (diffG << 8) | diffB;
		// Save the current color into the 'previous' buffer
		$previousFrame[i] = currColor;
	}
	// To prevent flicker from frames that are all black (no movement),
	// only update the screen if the image has changed.
	if (movementSum > 0) {
		video.updatePixels();
	}
}

public void FX_add(PImage video) {
	video.loadPixels(); // Make its pixels[] array available
        $numPixels = video.pixels.length;
	float gamma = map($FXLevel, 0, 255, 0.2f, 2.5f);

	for (int i = 0; i < $numPixels; i++) { // For each pixel in the video frame...
		int currColor = video.pixels[i];
		int prevColor = $previousFrame[i];
		// Extract the red, green, and blue components from current pixel
		int currR = (currColor >> 16) & 0xFF; // Like red(), but faster
		int currG = (currColor >> 8) & 0xFF;
		int currB = currColor & 0xFF;
		// Extract red, green, and blue components from previous pixel
		int prevR = (prevColor >> 16) & 0xFF;
		int prevG = (prevColor >> 8) & 0xFF;
		int prevB = prevColor & 0xFF;
		// Compute the new red, green, and blue values
				
		// screen blend:
		float newR = 255 - (PApplet.parseFloat((255-currR)*(255-prevR)) / 255);
		float newG = 255 - (PApplet.parseFloat((255-currG)*(255-prevG)) / 255);
		float newB = 255 - (PApplet.parseFloat((255-currB)*(255-prevB)) / 255);
		
		// gamma:
		newR = newR * newR * gamma / 255 - (64 - (32*gamma));;
		newR = (newR > 255) ? 255 : newR;
		newR = (newR < 0) ? 0 : newR;
		newG = (newG * newG * gamma / 255) - (64 - (32*gamma));
		newG = (newG > 255) ? 255 : newG;
		newG = (newG < 0) ? 0 : newG;
		newB = newB * newB * gamma / 255 - (64 - (32*gamma));;
		newB = (newB > 255) ? 255 : newB;
		newB = (newB < 0) ? 0 : newB;
		
		// The following line is much faster, but more confusing to read
		video.pixels[i] = 0xff000000 | (PApplet.parseInt(newR) << 16) | (PApplet.parseInt(newG) << 8) | PApplet.parseInt(newB);
		// Save the current color into the 'previous' buffer
		$previousFrame[i] = currColor;
	}
	video.updatePixels();
}

public void FX_gamma(PImage video) {
	video.loadPixels(); // Make its pixels[] array available
        $numPixels = video.pixels.length;
	float gamma = map($FXLevel, 0, 255, 0.2f, 4);

	for (int i = 0; i < $numPixels; i++) { // For each pixel in the video frame...
		int currColor = video.pixels[i];
		// Extract the red, green, and blue components from current pixel
		int currR = (currColor >> 16) & 0xFF; // Like red(), but faster
		int currG = (currColor >> 8) & 0xFF;
		int currB = currColor & 0xFF;

		// screen blend:
		float newR = PApplet.parseFloat(currR);
		float newG = PApplet.parseFloat(currG);
		float newB = PApplet.parseFloat(currB);
		
		// gamma:
		newR = newR * newR * gamma / 255 - (64 - (32*gamma));;
		newR = (newR > 255) ? 255 : newR;
		newR = (newR < 0) ? 0 : newR;
		newG = (newG * newG * gamma / 255) - (64 - (32*gamma));
		newG = (newG > 255) ? 255 : newG;
		newG = (newG < 0) ? 0 : newG;
		newB = newB * newB * gamma / 255 - (64 - (32*gamma));;
		newB = (newB > 255) ? 255 : newB;
		newB = (newB < 0) ? 0 : newB;
		
		// The following line is much faster, but more confusing to read
		video.pixels[i] = 0xff000000 | (PApplet.parseInt(newR) << 16) | (PApplet.parseInt(newG) << 8) | PApplet.parseInt(newB);
		// Save the current color into the 'previous' buffer
		$previousFrame[i] = currColor;
	}
	video.updatePixels();
}
/*
 * Multiple live / recorded video projection (Processing 1.5 only!)
 * by Eduardo Morais 2012
 */

//
// KEYBINDINGS
//
public void keyPressed() {
	if (key == CODED) {
		// help:
		if (keyCode == KeyEvent.VK_F1) {
			if ($showHelp) {
				$showHelp = false;
			} else {
				$showHelp = true;
				println("HELP!");
			}
			background(0);
		}

		// adjust video positions:
		if (keyCode == KeyEvent.VK_PAGE_UP) {
			$offsetY -= 5;
		}
		if (keyCode == KeyEvent.VK_PAGE_DOWN) {
			$offsetY += 5;
		}

		// effect level + ghosting:
		if (keyCode == UP && $FX > 0 && $FXLevel < 255) {
			$FXLevel++;
		}
		if (keyCode == DOWN && $FX > 0 && $FXLevel > 0) {
			$FXLevel--;
		}
		if (keyCode == LEFT && $FX == 0 && $Ghosting > 1) {
			$Ghosting--;
		}
		if (keyCode == RIGHT && $FX == 0 && $Ghosting < 25) {
			$Ghosting++;
		}

		// advance at random:
		if (keyCode == KeyEvent.VK_F9) {
			if ($Playing && $Video!=null && $Video.isPlaying()) {
				videoPlaylist(true, true);
			}
		}

		// fullscreen:
		if (keyCode == KeyEvent.VK_F3) {
			if ($Canvas.isFullScreen()) {
				$Canvas.leave();
				$canvasWidth = $windowWidth;
				$canvasHeight = $windowHeight;
				size($windowWidth, $windowHeight);
			} else {
				$Canvas.enter();
				$canvasWidth = screen.width;
				$canvasHeight = screen.height;
				size(screen.width, screen.height);
			}
			liveRatioAdjust();
		}
	}



	// play/pause:
	if (key == ' ') {
		if ($Playing && $Video!=null && $Video.isPlaying()) {
			$Playing = false;
			$Video.pause();
			println("Video paused.");
		} else {
			$Playing = true;
			println("Video playing.");
			if ($Video !=null && $Video.isPaused()) {
				$Video.play();
			}
		}
	}

	// advance to next video:
	if (key == 'n' || key == 'N') {
		if ($Playing && $Video!=null && $Video.isPlaying()) {
			videoPlaylist(true, false);
		}
	}


	// swap camera / video:
	if (key == 's' || key == 'S') {
		int vp = 999;
		int cp = 999;

		for (int i = $gridPositions - 1; i >= 0; i--) {
			if ($Grid[i] == 100) {
				vp = i;
			}
			if ($Grid[i] < $liveLength && !int_in_array($Grid[i], $lockLive)) {
				cp = i;
			}
		}

		// simple swap:
		if (cp < $gridPositions && vp < $gridPositions) {
			$Grid[vp] = $Grid[cp];
			$Grid[cp] = 100;
		} else if (cp < $gridPositions) {
			// only camera visible:
			if (cp == 0 && !int_in_array($Grid[1], $lockLive)) {
				$Grid[1] = $Grid[0];
				$Grid[0] = 100;
			} else if (!int_in_array($Grid[0], $lockLive)) {
				$Grid[0] = $Grid[cp];
				$Grid[cp] = 100;
			}
		} else if (vp < $gridPositions) {
			// only video visible:
			if (vp == 0 && !int_in_array($Grid[1], $lockLive)) {
				$Grid[1] = 100;
				$Grid[0] = 0;
			} else if (!int_in_array($Grid[0], $lockLive)) {
				$Grid[0] = 100;
				$Grid[vp] = 0;
			}
		} else if (!int_in_array($Grid[0], $lockLive) && !int_in_array($Grid[1], $lockLive)) {
			// both invisible
			$Grid[0] = 0;
			$Grid[1] = 100;
		}
		background(0);
	}


	// toggle camera:
	if (key == 'c' || key == 'C') {
		println($lockLive);
		if ($Live != null && $liveLength > 1) {
			for (int i = 0; i < $gridPositions; i++) {
				if ($Grid[i] < $liveLength && !int_in_array($Grid[i], $lockLive)) {
					int ng = $Grid[i] + 1;
					if (ng >= $liveLength) {
						ng = 0;
					}
					if (!int_in_array(ng, $lockLive)) {
						$Grid[i] = ng;
					}
				}
			}
		}
	}

	// toggle grid position:
	if (key >= '1' && key <= '5') {
		int k = key - '1';
		int gp = $Grid[k];

		if ($Live != null && k < $gridPositions) {
			gp++;
			if (gp > 999) {
				gp = 0;
			} else if (gp > 100) {
				gp = 999;
			} else if (gp >= $liveLength) {
				gp = 100;
			}

			$Grid[k] = gp;
			background(0);
		}
	}

	// grid control:
	if (key == 'g' || key == 'G') {
		$gridPositions++;
		if ($gridPositions > 5) {
			$gridPositions = 2;
		}
		background(0);
	}


	// toggle feed mode:
	if (key == ENTER || key == RETURN) {
		if (!$fillScreen) {
			$fillScreen = true;
			println("Single feed mode");
		} else {
			$fillScreen = false;
			println("Dual feed mode");
		}
		background(0);
	}

	// select FX:
	if ((key >= '6' && key <= '9') || key == '0') {
		int fx = 0;
		if (key == '0') {
			fx = 5;
		} else {
			fx = key - '5';
		}
		if ($FX == fx ) {
			$FX = 0; // off
			println("Effect off.");
		} else {
			$FX = fx;
			println("Effect " + $FX + " on.");
		}
	}

	// toggle capture ratio adjust:
	/* CRASHY!
	if (key == 'a' || key == 'A') {
		if ($ratioAdjust) {
			$ratioAdjust = false;
		} else {
			$ratioAdjust = true;
		}
		liveRatioAdjust();
		background(0);
	}
	*/

	// fade in/out
	if (key == 'f' || key == 'F') {
		if ($fading == 0) {
			if ($fade == 255) {
				$fading = 0 - $fadeSpeed;
				println("Fade out");
			}
			if ($fade == 0) {
				$fading = $fadeSpeed;
				println("Fade in");
			}
		}
	}

	// quit:
	if (key == 'q' || key == 'Q') {
	/* // should be here but crashes - WTF?
		for (int i=0; i<$liveLength; i++) {
			if ($Live[i] != null) {
				$Live[i].stop();
				$Live[i].dispose();
			}
		}
	*/
		if ($Video != null) {
			$Video.stop();
			$Video.dispose();
		}
		exit();
	}
}

// clear screen on release
public void keyReleased() {
	if (key == CODED) {
		if (keyCode == UP || keyCode == DOWN) {
			background(0);
		}
	}
}
/*
 * Multiple live / recorded video projection (Processing 1.5 only!)
 * by Eduardo Morais 2012
 */

/*
 * Utilities
 */

// returns all the videos in a directory as an array of Strings
public String[] listFileNames(String dir) {
	String VIDEO_PATTERN = "([^\\s]+((.*/)*.+\\.(?i)("+$okVideos+"))$)";
	Pattern pattern = Pattern.compile(VIDEO_PATTERN);
	File file = new File(dir);
	if (file.isDirectory()) {
		String names[] = file.list();
		int v = 0;
		String[] videos = new String[names.length];
		for (int i = 0; i < names.length; i++) {
			Matcher matcher = pattern.matcher(names[i]);
			if (matcher.matches()) {
				videos[v] = names[i];
				v++;
			} else {
				videos = shorten(videos);
			}
		}
		return videos;
	} else {
		// If it's not a directory
		return null;
	}
}

// int in array?
public static boolean int_in_array(int n, int[] arr) {
	if (arr != null && arr.length > 0) {
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == n) {
				return true;
			}
		}
	}
	return false;
}


/**
 * simple convenience wrapper object for the standard
 * Properties class to return pre-typed numerals
 */
class Config extends Properties {

  public boolean getBoolean(String id, boolean defState) {
    return PApplet.parseBoolean(getProperty(id,""+defState));
  }

  public int getInt(String id, int defVal) {
    return PApplet.parseInt(getProperty(id,""+defVal));
  }

  public float getFloat(String id, float defVal) {
    return PApplet.parseFloat(getProperty(id,""+defVal));
  }

  public String getString(String id, String defVal) {
    return getProperty(id,""+defVal);
  }

  public int[] getIntArray(String id) {
 	String[] str = getProperty(id).split("[, ]+");
 	int[] arr = new int[str.length];
 	for(int i = 0; i < arr.length; i++) {
 		arr[i] = -1;
 	}
  	for(int i = 0; i < str.length; i++) {
  		if (int_in_array(PApplet.parseInt(str[i]), arr) == false) {
	 	   arr[i] = PApplet.parseInt(str[i]);
		} else {
			arr = shorten(arr);
		}
	}
	println(arr);
	return arr;
  }

}
  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#F0F0F0", "MultiProjection" });
  }
}
