
Multiple live / recorded video projection (made with Processing 1.5)
by Eduardo Morais 2012

http://github.com/edmorais/Processing

Tested successfully on Windows 7x64.
Requires Quicktime and WinVDIG *1.0.1* - http://www.eden.net.nz/7/20071008


Options can be set by editing config.txt. Enjoy!